//
//  VMLPlayerController.h
//  VMLPlayerController
//
//  Created by Kris Jones on 01/06/2021.
//

#import <Foundation/Foundation.h>


//! Project version number for VMLPlayerController.
FOUNDATION_EXPORT double VMLPlayerControllerVersionNumber;

//! Project version string for VMLPlayerController.
FOUNDATION_EXPORT const unsigned char VMLPlayerControllerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VMLPlayerController/PublicHeader.h>


